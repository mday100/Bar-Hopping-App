class Comment < ActiveRecord::Base
  belongs_to :location
end
